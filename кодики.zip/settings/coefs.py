#КЭФЫ

DICE = 1.6 #ЧЕТ НЕЧЕТ КУБ
DICE_MORE_LESS = 1.5#БОЛЬШЕ МЕНЬШЕ
DICE_NUMBER = 3 #ЧИСЛО
DUEL = 1.6 #ДУЭЛЬ
DARTS = 3 #ДАРТС
DARTS_COLOR = 1.7 #ДАРТС КРАСН/БЕЛ
BASKET = 1.7 #БАСКЕТ
BASKET_MISS = 1.2 #БАСКЕТ МИМО
FOOTBALL = 1.2 #ФУТБОЛ
FOOTBALL_MISS = 1.7#ФУТБОЛ МИМО
BOWLING = 3 #БОУЛИНГ
SLOTS_777 = 10 #СЛОТЫ 777
SLOTS_GRAPE = 3 #СЛОТЫ ВИНОГРАД
SLOTS_BAR = 3 #СЛОТЫ БАР
SLOTS_LEMON = 2.5 #СЛОТЫ ЛИМОН
KNB = 1.6 #КАМЕНЬ НОЖНИЦЫ БУМАГА
COIN = 1.4 #ОРЕЛ РЕШКА