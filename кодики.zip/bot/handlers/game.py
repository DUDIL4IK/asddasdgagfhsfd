from aiogram.types import Message, ChatType
from aiogram.dispatcher.filters import ChatTypeFilter
from aiogram import Dispatcher
from aiogram.utils.deep_linking import decode_payload, get_start_link

from settings import keywords, coefs
from settings.constants import knb, coins
from bot.utils import func, game_procces
from bot.utils.cryptopay import get_balance, crypto
import asyncio, config, main, random
from bot import keyboards

#ОСТОРОЖНО ВНИЗУ ГАВНОКОД ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓
async def getter(msg_query: Message):
    """Пиздец"""
    if msg_query.chat.id == config.CHANNEL_BROKER: #проверка чтобы сообщение было в канале посреднике
        if msg_query.entities: #првоеряем на наличие entities
            amount = float(msg_query.text.split("отправил(а)")[1].split()[0].replace(',', "")) #получаем сумму ставки
            asset = msg_query.text.split("отправил(а)")[1].split()[1]
            name = msg_query.text.split("отправил(а)")[0] #получаем имя чела
            if msg_query.entities[0].user: #проверяем есть ли ссылка на чела
                user = msg_query.entities[0].user
                username = f"@{user.username}" if user.username else user.full_name
                name = user.full_name #снова получаем имя более надежным способом
                msg_text = msg_query.text.removeprefix(name) #удаляем имя из сообщения от греха подальше
                user_id = int(user.id)
                asset =  msg_text.split("отправил(а)")[1].split()[1]
                amount = float(msg_text.split("отправил(а)")[1].split()[0].replace(',', ""))
                coef = 0
                if user_id not in main.db.get_bannned(): #провека чтобы чел не был в бане
                    if "💬 " in msg_query.text: #проверяме на наличие комента
                        old_comment = msg_query.text.split("💬 ")[1]
                        comment = old_comment.lower()
                        comment = comment.replace('ё', 'е') 
                        gp = game_procces.GameProcess(amount, asset, coef, user_id, username)
                        message = await main.bot.send_message(config.MAIN_CHANNEL, f"*{msg_query.entities[0].user.full_name}* поставил *{round(amount, 3)} {asset}*\n\n💬{old_comment}", 'markdown')
                        if func.contains(keywords.DICE, comment):
                            new_com = func.remove_prefixes(keywords.DICE, comment)
                            if new_com.isdigit() and new_com != "456" and new_com != "123" and new_com != "321" and new_com != "654" and new_com != "246" and new_com != "135":
                                    n = int(new_com)
                                    if 0 < n < 7:
                                        await gp.dice_procces(message, "number", n)
                                    else:
                                        await func.invalid_syntax(message, amount, asset, user_id, username)
                            elif func.equals(keywords.EVEN, new_com):
                                await gp.dice_procces(message, "even")
                            elif func.equals(keywords.ODD, new_com):
                                await gp.dice_procces(message, "odd")
                            elif func.equals(keywords.MORE, new_com):
                               await gp.dice_procces(message, "more")
                            elif func.equals(keywords.LESS, new_com):
                                await gp.dice_procces(message, "less")
                            elif new_com == "дуэль":
                                await gp.duel_proccess(message)
                            else:
                                await func.invalid_syntax(message, amount, asset, user_id, username)
                        elif func.contains(keywords.DARTS, comment):
                            new_com = func.remove_prefixes(keywords.DARTS, comment)
                            if func.equals(keywords.RED, new_com):
                                await gp.darts_procces(message, 'r')
                            elif func.equals(keywords.WHITE, new_com):
                                await gp.darts_procces(message, 'w')
                            elif func.equals(keywords.CENTER, new_com):
                                await gp.darts_procces(message)
                            elif new_com == "дуэль":
                                await gp.duel_proccess(message, '🎯')
                            else:
                                await func.invalid_syntax(message, amount, asset, user_id, username)
                        elif func.contains(keywords.BASKET, comment):
                                new_com = func.remove_prefixes(keywords.BASKET, comment)
                                if func.equals(keywords.GOAL, new_com):
                                    await gp.basketball_process(message)
                                elif func.equals(keywords.MISS, new_com):
                                    await gp.basketball_process(message, 'miss')
                                else:
                                    await func.invalid_syntax(message, amount, asset, user_id, username)
                        elif func.contains(keywords.FOOTBALL, comment):
                            new_com = func.remove_prefixes(keywords.FOOTBALL, comment)
                            if func.equals(keywords.GOAL, new_com):
                                await gp.footaball_process(message)
                            elif func.equals(keywords.MISS, new_com):
                                await gp.footaball_process(message, 'miss')
                            else:
                                await func.invalid_syntax(message, amount, asset, user_id, username)
                        elif func.contains(keywords.BOWLING, comment):
                            new_com = func.remove_prefixes(keywords.BOWLING, comment)
                            if new_com.isdigit():
                                stake = int(new_com)
                                if -1 < stake < 7:
                                    await gp.bowling_process(message, stake)
                            elif func.equals(keywords.STRIKE, new_com):
                                await gp.bowling_process(message, 0)
                            else:
                                await func.invalid_syntax(message, amount, asset, user_id, username)
                        elif func.contains(keywords.SLOTS, comment):
                            new_com = func.remove_prefixes(keywords.SLOTS, comment)
                            if new_com.isdigit():
                                total = int(new_com)
                                if 0 < total < 6:
                                    slots = []
                                    winning = 0
                                    once_amount = amount / total
                                    if  asset == "USDT" and once_amount >= 0.05 or asset=="TON" and once_amount >= 0.023:
                                        for i in range(total):
                                            msg = await message.reply_dice('🎰')
                                            slots.append(msg.dice.value)
                                        for slot in slots:
                                            val = slot
                                            if val == 64:
                                                winning += once_amount * coefs.SLOTS_777#777
                                            elif val == 1 or val==22:
                                                winning += once_amount * coefs.SLOTS_BAR #bar and grape
                                            elif val == 43:
                                                winning += once_amount * coefs.SLOTS_LEMON
                                        if winning > 0:
                                            await func.winner(message, winning, asset, 1, user_id, username)
                                    else:
                                        if amount < dict(await get_balance())[asset]:
                                            check = await crypto.create_check(asset, amount)
                                            main.db.add_check(user_id, check.check_id)
                                            await message.reply("*❗Слишком маленькая ставка!*\n⚡Цена одного слота 0.05$!\n\nНажмите на кнопку ниже, чтобы вернуть деньги", 'markdown', reply_markup=keyboards.functional.create_url_button(await get_start_link(user_id, True),  "Вернуть💸"))
                                        else:
                                            await message.reply("*❗Слишком маленькая ставка*\n⚡Цена одного слота 0.05$\n\n👇Напишите администрации для возвращения средств!", 'markdown')
                                else:
                                    await func.invalid_syntax(message, amount, asset, user_id, username)
                            else:
                                await func.invalid_syntax(message, amount, asset, user_id, username)
                        elif "мины " in comment:
                            if not main.db.user_played_mines(user_id):
                                new_com = comment
                                new_com = new_com.removeprefix("мины ")
                                if new_com.isdigit():
                                    n = int(int(new_com))
                                    if 25 > n > 2:
                                        c = 0
                                        coef = 1
                                        await message.reply(f"*⚡Выберете любой слот*\n*Клеток открыто:* 0\n*Коэффицент:* 1X\n*Выигрыш:* {round(amount * coef, 2)}  {asset}", 'markdown', reply_markup=keyboards.functional.create_mine_keyboards(n, user_id, amount, asset, username))
                                    else:
                                        await func.invalid_syntax(message, amount, asset, user_id, username)
                                else:
                                    await func.invalid_syntax(message, amount, asset, user_id, username)
                            else:
                                if amount < dict(await get_balance())[asset]:
                                    check = await crypto.create_check(asset, amount)
                                    main.db.add_check(user_id, check.check_id)
                                    await message.reply("*❗Вы ещё не завершили предыдущую игру*\n\n👇Нажмите на кнопку ниже, чтобы вернуть деньги", 'markdown', reply_markup=keyboards.functional.create_url_button(await get_start_link(user_id, True), "Вернуть💸"))
                                else:
                                    await message.reply("*❗Вы ещё не завершили предыдущую игру*\n\nНапишите администрации для возвращения средств!", 'markdown')
                        else:
                            if func.equals(keywords.EVEN, comment):
                                await gp.dice_procces(message, 'even')
                            elif func.equals(keywords.ODD, comment):
                                await gp.dice_procces(message, 'odd')
                            elif func.equals(keywords.LESS, comment):
                                await gp.dice_procces(message, 'less')
                            elif func.equals(keywords.MORE, comment):
                                await gp.dice_procces(message, 'more')
                            elif func.equals(keywords.RED, comment):
                                await gp.darts_procces(message, 'r')
                            elif func.equals(keywords.WHITE, comment):
                                await gp.darts_procces(message, 'w')
                            elif func.equals(keywords.DARTS, comment) or func.equals(keywords.CENTER, comment):
                                await gp.darts_procces(message)
                            elif func.equals(keywords.BASKET, comment):
                                await gp.basketball_process(message)
                            elif func.equals(keywords.FOOTBALL, comment):
                                await gp.footaball_process(message)
                            elif func.equals(keywords.BOWLING, comment) or func.equals(keywords.STRIKE, comment):
                                await gp.bowling_process(message, 0)
                            elif func.equals(keywords.SLOTS, comment):
                                msg = await message.answer_dice('🎰')
                                v = msg.dice.value
                                await asyncio.sleep(6)
                                if v == 64:
                                    await func.winner(message, amount, asset, coefs.SLOTS_777 + coef, user_id, username) #777
                                elif v == 1 or v==22:
                                    await func.winner(message, amount, asset, coefs.SLOTS_GRAPE + coef, user_id,  username) #bar and grape
                                elif v == 43:
                                    await func.winner(message, amount, asset, coefs.SLOTS_LEMON + coef, user_id, username)
                            elif comment in ["камень", "ножницы", "бумага"]:
                                await gp.knb_procces(message, comment)
                            else:
                                await func.invalid_syntax(message, amount, asset, user_id, username)
                    else:
                        #если нет комента
                        message = await main.bot.send_message(config.MAIN_CHANNEL, f"*{msg_query.entities[0].user.full_name}* поставил *{round(amount, 3)} {asset}*\n\n❌Нет комментария!", 'markdown')
                        await func.invalid_syntax(message, amount, asset, user_id, username)
                else:
                    #если бан
                    await main.bot.send_message(config.LOG_CHANNEL, f"Забанненый {username}({user_id}) отправил {amount} {asset}")
            else:
                #если нет ссылки на акк
                await main.bot.send_message(config.LOG_CHANNEL, f"Не удалось распознать пользователя с именем {name}! Его ставка {amount} {asset}")
                unknown_user_message = await main.bot.send_message(config.MAIN_CHANNEL, f"❗Мы не смогли опознать человека с именем <b>{name}</b>! Пиши в лс админам\n\n⚠️Проблема возможно возникла из-за ваших настроек приватности!", "html")
                await asyncio.sleep(30)
                await unknown_user_message.delete()

def register_handlers(dp: Dispatcher):
    dp.register_channel_post_handler(getter, ChatTypeFilter(ChatType.CHANNEL), text_contains="отправил(а)")
