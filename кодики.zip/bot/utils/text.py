from bot.utils import cryptopay

import string, random

async def get_admin_menu_text():
    return f"""Админское меню:
CryptoBot
USDT 
Доступно: {round(dict(await cryptopay.get_balance())['USDT'], 3)}
В ожидании: {round(dict(await cryptopay.get_hold())['USDT'], 3)}
TON
Доступно: {round(dict(await cryptopay.get_balance())['TON'], 3)}
В ожидании: {round(dict(await cryptopay.get_hold())['TON'], 3)}
    """

def rnd_id():
    al = string.ascii_letters
    txt = ""
    for i in range(1, 10):
        txt += random.choice(al)
    return txt