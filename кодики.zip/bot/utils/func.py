from aiogram.utils.deep_linking import decode_payload, get_start_link
from aiogram.types import Message

import main as m
import config
from bot.utils.cryptopay import get_balance, crypto
from bot.utils import text
from bot import keyboards
import base64, datetime

def check_button_back(buttons) -> bool:
    for keyboard in buttons:
        for button in keyboard:
            if button.text == "Забрать":
                return False
    return True
   
def check_winning(id, buttons) -> bool:
    for keyboard in buttons:
        for button in keyboard:
            if button.callback_data != "finish" and "stop_" not in button.callback_data:
                i = int(button.callback_data.split('_')[2])
                if i not in m.db.get_bad_mines(id) and i != -1:
                    return False
    return True

def remaining_slots(buttons: list, id: int) -> int:
    i = 0
    for keyboard in buttons:
        for button in keyboard:
            if "stop_" not in button.callback_data:
                if button.callback_data != "ready_empty_-1" and int(button.callback_data.split('_')[2]) not in m.db.get_bad_mines(id):
                    i = i + 1
    return i

def contains(l, item) -> bool:
    for el in l:
        if el + " " in item:
            return True
    return False

def equals(l, item) -> bool:
    for el in l:
        if el==item:
            return True
    return False

def remove_prefixes(l: list, item: str):
    for el in l:
        item = item.removeprefix(el + " ")
    return item

async def winner(message: Message, amount, asset, coef, user_id, username):
        if amount*coef < dict(await get_balance())[asset]:
            if amount*coef > 1:
                await crypto.transfer(user_id, asset, amount * coef, text.rnd_id())
                await message.reply(f"*🎉Вы выиграли {round(amount * coef, 3)} {asset}\n\n👇Выигрыш зачислен на ваш баланс*", 'markdown',
                                    reply_markup=keyboards.functional.create_url_button(config.INVOICE_URL,"Сделать Ставку"))
            else:
                check = await crypto.create_check(asset, amount * coef)
                m.db.add_check(user_id, check.check_id)
                await message.reply(f"*🎉Вы выиграли {round(amount * coef, 3)} {asset}\n\n👇Заберите выигрыш по кнопке ниже*", 'markdown',
                                    reply_markup=keyboards.functional.create_double_button(await get_start_link(user_id, True)))
        else:
            await m.bot.send_message(config.LOG_CHANNEL, f"{username} ({user_id}) выиграл {round(amount * coef, 3)} {asset}. ЗАДОЛЖЕННОСТЬ!")
            await message.reply(f"*😔Казна казино пуста!*\nНапишите администрации для получения выигрыша!\n\n*Ваш выигрыш: {round(amount * coef, 3)} {asset}*", 'markdown')

async def invalid_syntax(message: Message, amount, asset, user_id, username):
    if amount < dict(await get_balance())[asset]:
        if amount > 1:
                await crypto.transfer(user_id, asset, amount, text.rnd_id())
                await message.reply(f"*❌Команда не найдена!*\n⚡Убедитесь что такая команда существует и она была написана правильно!\n\n💸Деньги возвращены на ваш баланс", 'markdown',
                                    reply_markup=keyboards.functional.create_url_button(config.INVOICE_URL,"Сделать Ставку"))
        else:
            check = await crypto.create_check(asset, amount)
            m.db.add_check(user_id, check.check_id)
            await message.reply("*❌Команда не найдена!*\n⚡Убедитесь что такая команда существует и она была написана правильно!\n\nЗаберите деньги по кнопке ниже👇", 'markdown', reply_markup=keyboards.functional.create_double_button(await get_start_link(user_id, True), "Вернуть💸"))
    else:
        await m.bot.send_message(config.LOG_CHANNEL, f"❗{username} ({user_id}) ошибся в синтаксесе. {round(amount, 3)} {asset.upper()}. ЗАДОЛЖЕННОСТЬ!")
        await message.reply("❗*❌Команда не найдена!*\n⚡Убедитесь что такая команда существует и она была написана правильно!\n\nНапишите администрации для возвращения средств!", 'markdown')